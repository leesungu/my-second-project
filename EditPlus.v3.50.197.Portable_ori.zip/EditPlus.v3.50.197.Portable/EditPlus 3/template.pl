#!/usr/bin/perl
use strict;
use warnings;

print "Hello, World...\n";
^!
