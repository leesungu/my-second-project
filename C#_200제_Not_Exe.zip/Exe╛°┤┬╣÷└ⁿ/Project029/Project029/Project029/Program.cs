﻿using System;
using Com.JungBo.Game;
namespace Com.JungBo.Basic
{
    public class Program
    {
        public static void Main(string[] args)
        {
            EachNumber tsn = new EachNumber();
            tsn.PrintSum(100);
        }
    }
}
