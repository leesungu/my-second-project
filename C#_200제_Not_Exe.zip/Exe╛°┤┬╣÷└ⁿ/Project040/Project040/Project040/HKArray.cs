using System;
namespace Com.JungBo.Maths{
    public class HKArray{
        //���� ũ���� m,n �迭�� ���� �ٲٱ�
        public static void SwapArray(int[]m,int []n) {
            int count = m.Length;
            int[] temp = new int[count];//0���� �ʱ�ȭ
            //m->temp
            Array.Copy(m, temp, count);
            //n->m
            Array.Copy(n, m, count);
            //temp->n
            Array.Copy(temp,n, count);
        }//SwapArray
        public static void PrintArray(int[]m) {
            foreach (int num in m){
                Console.Write("{0}  ",num);
            }
            Console.WriteLine();
        }//PrintArray
		
        public static void Clear(int []m, int n) {
            if (n == 0){
                //0���� �����
                Array.Clear(m, 0, m.Length);
            }
            else {
                for (int i = 0; i < m.Length; i++){
                    m[i] = n;//n���� ��� �����
                }
            }//else
        }//Clear
    }
}
