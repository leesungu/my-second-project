using System;
using System.Collections.Generic;
using System.Text;

namespace Com.JungBo.Logics{
    //���������� &&, ||
    public class HechoCalendar{
        public bool IsLeapYear(int year){
            bool isL = false;
            //A-B+c
            if (((year % 4 == 0) && (year % 100 != 0)) 
                          ||  (year % 400 == 0)  ){
                isL = true;
            }
            return isL;
        }//IsLeapYear

        public void PrintLeapYear(int sy, int ey){
            for (int i = sy; i <= ey; i++)
            {
                if (IsLeapYear(i))
                {
                    Console.WriteLine("{0}�� �����Դϴ�.", i);
                }
            }
        }//PrintLeapYear

    }//HechoCalendar
}
