﻿using System;
using Com.JungBo.Logic;
namespace Com.JunBo.Basic
{
    public class Program
    {
        public static void Main(string[] args)
        {
            TetrisRotate tr = new TetrisRotate();
            tr.Print();
        }
    }
}
