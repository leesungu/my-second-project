﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project010
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //키워드 -> 소문자 using, namespace,
            //public, static, class, void
            //파스칼(대문자+소문자) Program, Project010, Main
            //카멜(소문자+대문자) int newValue=1000;
            int @if = 234;
            int _if_ = 345;
            int i3Num = 3;
            int ii3Num = 4;

            Console.WriteLine(@if);
            Console.WriteLine(_if_);

        }
    }
}
