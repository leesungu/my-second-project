namespace LinkTest
{
    partial class Student
    {
    }
}
