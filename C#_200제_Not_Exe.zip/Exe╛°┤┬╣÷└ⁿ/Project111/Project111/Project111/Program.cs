﻿using System;
using System.Threading;
using Com.JungBo.Proce;
namespace Project107
{
    public class Program
    {
        public static void Main(string[] args)
        {

            ThreadCompete tc = new ThreadCompete();
            tc.Going();

        }
    }
}
