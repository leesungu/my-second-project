﻿using System;
using Com.JungBo.Proce3;
namespace ThreadProject02
{
    public class Program
    {
        public static void Main(string[] args)
        {
            ThreadCompete tcomp = new ThreadCompete();
            tcomp.Going();
        }
    }
}
