﻿using System;
using Com.JungBo.Proce;
namespace Project109
{
    public class Program
    {
        public static void Main(string[] args)
        {
            ThreadCompete tcomp = new ThreadCompete();
            tcomp.Going();
        }
    }
}
