﻿using System;
using Com.JungBo.Proce;
namespace Project110
{
    public class Program
    {
        public static void Main(string[] args)
        {
            ThreadCompete tc = new ThreadCompete();
            tc.Going();
        }
    }
}
