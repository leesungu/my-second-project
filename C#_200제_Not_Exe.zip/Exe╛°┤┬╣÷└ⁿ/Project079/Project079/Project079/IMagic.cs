namespace Com.JunBo.Logic {
    public interface IMagic{
        void Print();
    }
}
