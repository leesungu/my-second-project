using System; 
 
namespace FloatingPoint 
{ 
    class MainApp 
    { 
        static void Main(string[] args) 
        { 
            float a  = 3.14159265358979323846f; 
            Console.WriteLine(a); 
 
            double b = 3.14159265358979323846; 
            Console.WriteLine(b); 
 
        } 
    } 
} 
