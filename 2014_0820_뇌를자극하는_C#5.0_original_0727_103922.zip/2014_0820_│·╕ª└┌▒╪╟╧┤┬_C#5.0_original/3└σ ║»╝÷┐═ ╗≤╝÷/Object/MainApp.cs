using System; 
 
namespace Object 
{ 
    class Program 
    { 
        static void Main(string[] args) 
        { 
            object a = 123; 
            object b = 3.141592653589793238462643383279m; 
            object c = true; 
            object d = "�ȳ��ϼ���."; 
 
            Console.WriteLine(a); 
            Console.WriteLine(b); 
            Console.WriteLine(c); 
            Console.WriteLine(d); 
        } 
    } 
}
